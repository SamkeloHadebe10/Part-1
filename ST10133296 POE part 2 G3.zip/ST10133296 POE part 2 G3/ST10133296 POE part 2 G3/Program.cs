﻿using ST10133296_POE_part_2_G3;
using System.Collections.Generic;
using System;
using System.Linq;

internal class Program
{
    // delegate for displaying recipes
    delegate void DisplayRecipeDelegate();

    static List<Recipe> recipes = new List<Recipe>();

    static void Main(string[] args)
    {
        int option = 0;

        ConsoleColor previousColor = Console.ForegroundColor;

        while (option != 6)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            // Display the menu options
            Console.WriteLine("-------------------------------------------------------");
            Console.WriteLine("|                  Recipe App Menu:                   |");
            Console.WriteLine("-------------------------------------------------------");
            Console.WriteLine("|    1. Add Recipe                                    |");
            Console.WriteLine("|    2. Display Recipe                                |");
            Console.WriteLine("|    3. Scale Recipe                                  |");
            Console.WriteLine("|    4. Reset Quantities                              |");
            Console.WriteLine("|    5. Delete Recipe                                 |");
            Console.WriteLine("|    6. Exit App                                      |");
            Console.WriteLine("-------------------------------------------------------");
            Console.WriteLine("| Enter your choice (1-6):                            |");
            Console.WriteLine("-------------------------------------------------------");

            Console.ForegroundColor = previousColor;
            // Get the user's menu choice
            if (int.TryParse(Console.ReadLine(), out option))
            {
                switch (option)
                {
                    case 1:
                        AddRecipe();
                        break;
                    case 2:
                        // Create an instance of the delegate
                        DisplayRecipeDelegate displayRecipeDelegate = DisplayRecipe;
                        displayRecipeDelegate();
                        break;
                    case 3:
                        ScaleRecipe();
                        break;
                    case 4:
                        ResetQuantities();
                        break;
                    case 5:
                        DeleteRecipe();
                        break;
                    case 6:
                        Console.WriteLine("\nGoodbye!");
                        break;
                    default:
                        Console.WriteLine("\nInvalid option. Please try again.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("\nInvalid input. Please enter a number.");
            }
        }
    }

    // Method for adding a new recipe
    static void AddRecipe()
    {
        Console.WriteLine("\nEnter the name of the recipe: ");
        string name = Console.ReadLine();

        Recipe recipe = new Recipe(name);
        recipe.RecipeDetails();
        recipes.Add(recipe);

        Console.WriteLine("\nRecipe has been added.");
    }

    // Method for displaying a recipe
    static void DisplayRecipe()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("\nNo recipes found.");
            return;
        }

        Console.WriteLine("\nSelect a recipe to display:");

        // Get the names of all recipes and sort them alphabetically
        List<string> recipeNames = recipes.Select(recipe => recipe.Name).OrderBy(name => name).ToList();

        // Display the numbered list of recipe names
        for (int i = 0; i < recipeNames.Count; i++)
        {
            Console.WriteLine((i + 1) + ". " + recipeNames[i]);
        }

        Console.WriteLine("Enter the recipe number: ");
        if (int.TryParse(Console.ReadLine(), out int recipeIndex))
        {
            if (recipeIndex >= 1 && recipeIndex <= recipeNames.Count)
            {
                string selectedRecipeName = recipeNames[recipeIndex - 1];
                Recipe selectedRecipe = recipes.First(recipe => recipe.Name == selectedRecipeName);
                selectedRecipe.DisplayRecipe();
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a number.");
        }
    }

    // Method for scaling a recipe
    static void ScaleRecipe()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("\nNo recipes found.");
            return;
        }

        Console.WriteLine("\nSelect a recipe to scale:");

        // Display the numbered list of recipe names
        for (int i = 0; i < recipes.Count; i++)
        {
            Console.WriteLine((i + 1) + ". " + recipes[i].Name);
        }

        Console.WriteLine("Enter the recipe number: ");
        int recipeIndex = int.Parse(Console.ReadLine());

        if (recipeIndex >= 1 && recipeIndex <= recipes.Count)
        {
            Recipe selectedRecipe = recipes[recipeIndex - 1];

            Console.WriteLine("\nEnter the scale factor (0.5, 2, or 3): ");
            double scaleFactor = double.Parse(Console.ReadLine());

            selectedRecipe.ScaleRecipe(scaleFactor);
            Console.WriteLine("\nRecipe has been scaled.");
        }
        else
        {
            Console.WriteLine("Invalid recipe number.");
        }
    }

    // Method for resetting quantities in a recipe
    static void ResetQuantities()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("\nNo recipes found.");
            return;
        }

        Console.WriteLine("\nSelect a recipe to reset quantities:");

        // Display the numbered list of recipe names
        for (int i = 0; i < recipes.Count; i++)
        {
            Console.WriteLine((i + 1) + ". " + recipes[i].Name);
        }

        Console.WriteLine("Enter the recipe number: ");
        int recipeIndex = int.Parse(Console.ReadLine());

        if (recipeIndex >= 1 && recipeIndex <= recipes.Count)
        {
            Recipe selectedRecipe = recipes[recipeIndex - 1];
            selectedRecipe.ResetQuantities();
            Console.WriteLine("\nQuantities have been reset for the recipe.");
        }
        else
        {
            Console.WriteLine("Invalid recipe number.");
        }
    }

    // Method for deleting a recipe
    static void DeleteRecipe()
    {
        if (recipes.Count == 0)
        {
            Console.WriteLine("\nNo recipes found.");
            return;
        }

        Console.WriteLine("\nSelect a recipe to delete:");

        // Display the numbered list of recipe names
        for (int i = 0; i < recipes.Count; i++)
        {
            Console.WriteLine((i + 1) + ". " + recipes[i].Name);
        }

        Console.WriteLine("Enter the recipe number: ");
        if (int.TryParse(Console.ReadLine(), out int recipeIndex))
        {
            if (recipeIndex >= 1 && recipeIndex <= recipes.Count)
            {
                Recipe selectedRecipe = recipes[recipeIndex - 1];
                recipes.Remove(selectedRecipe);
                Console.WriteLine("\nRecipe has been deleted.");
            }
            else
            {
                Console.WriteLine("Invalid recipe number.");
            }
        }
        else
        {
            Console.WriteLine("Invalid input. Please enter a number.");
        }
    }
}
    

    

