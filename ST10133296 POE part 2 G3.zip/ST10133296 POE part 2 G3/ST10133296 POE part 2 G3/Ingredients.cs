﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10133296_POE_part_2_G3
{
    class Ingredient
    {
        private string name;
        private double quantity;
        private string unit;
        private int calories;
        private string foodGroup;

        public Ingredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            this.name = name;
            this.quantity = quantity;
            this.unit = unit;
            this.calories = calories;
            this.foodGroup = foodGroup;
        }

        public override string ToString()
        {
            return "Ingredient: " + name + "\nQuantity: " + quantity + " " + unit + "\nCalories: " + calories + "\nFood Group: " + foodGroup;
        }

        public void ScaleQuantity(double scaleFactor)
        {
            // Scale the quantity of the ingredient by the given factor
            quantity *= scaleFactor;
        }

        public void ResetQuantity()
        {
            // Reset the quantity of the ingredient to 0
            quantity = 0;
        }
    }

}

