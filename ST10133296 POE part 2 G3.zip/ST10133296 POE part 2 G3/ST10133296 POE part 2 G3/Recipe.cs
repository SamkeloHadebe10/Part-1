﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10133296_POE_part_2_G3
{
    class Recipe
    {
        private string name;
        private List<Ingredient> ingredients;

        public string Name { get { return name; } }

        public Recipe(string name)
        {
            this.name = name;
            ingredients = new List<Ingredient>();
        }

        public void RecipeDetails()
        {
            Console.WriteLine("\nEnter the number of ingredients: ");
            int numIngredients = int.Parse(Console.ReadLine());

            // Collect details for each ingredient and add them to the recipe
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine("\nEnter the name of ingredient " + (i + 1) + ": ");
                string ingredientName = Console.ReadLine();

                Console.WriteLine("Enter the quantity of " + ingredientName + ": ");
                double quantity = double.Parse(Console.ReadLine());

                Console.WriteLine("Enter the unit of measurement (l, ml, g, kg)");
                string unit = Console.ReadLine();

                Console.WriteLine("Enter the calories in " + ingredientName + ": ");
                int calories = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter the food group of " + ingredientName + ": ");
                string foodGroup = Console.ReadLine();

                Ingredient ingredient = new Ingredient(ingredientName, quantity, unit, calories, foodGroup);
                ingredients.Add(ingredient);
            }
        }

        public void DisplayRecipe()
        {
            ConsoleColor previousColor = Console.ForegroundColor;

            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            Console.WriteLine("Recipe: " + name);
            Console.WriteLine("^^^^^^^^^^^^^^^^^^^^^^^^^^^^");

            // Display details of each ingredient in the recipe
            foreach (Ingredient ingredient in ingredients)
            {
                Console.WriteLine( ingredient);
            }
            Console.WriteLine("^^^^^^^^^^^^^^^^^^^^^^^^^^^^");
            Console.ForegroundColor = previousColor;
        }

        public void ScaleRecipe(double scaleFactor)
        {
            // Scale the quantity of each ingredient in the recipe
            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.ScaleQuantity(scaleFactor);
            }
        }

        public void ResetQuantities()
        {
            // Reset the quantity of each ingredient in the recipe
            foreach (Ingredient ingredient in ingredients)
            {
                ingredient.ResetQuantity();
            }
        }
    }

}








