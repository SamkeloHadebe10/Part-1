namespace part_2_test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        { 
           displayRecipeDelegate();
        }
    }
}